package com.example.myapplication.Util;

public class util {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Restaurant_Database";
    public static final String TABLE_NAME = "restaurants";


    public static final String Res_ID ="Res_ID";
    public static final String Res_Name = "Res_Name";
    public static final String Res_LAT = "Res_Latitude";
    public static final String Res_LNG = "Res_Longitude";

    public static final String Key_Show_All_Res = "kew_show_all_res";
    public static final String Key_Rest_Name = "Key_rest_name";
    public static final String Key_Rest_LAT="Key_res_latitude";
    public static final String Key_Rest_LNG = "Key_res_Latitude";

}
