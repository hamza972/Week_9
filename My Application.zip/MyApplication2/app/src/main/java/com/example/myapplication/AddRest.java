package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.myapplication.Data.DatabaceHelper;
import com.example.myapplication.Model.Rest;
import com.example.myapplication.Util.util;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.SSLEngineResult;

public class AddRest extends AppCompatActivity {
    private double Lat, LNG;
    private EditText NameEdit;
    private EditText LocationEdit;

    public static final int AC_REQ_CODE = 14;
    public static final int LOC_PERM_REQ_CODE = 15;

    protected  void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addplace);

        NameEdit = findViewById(R.id.palceName);
        LocationEdit = findViewById(R.id.placeLocation);
    }

    protected void onActivityResult(int ReqCode, int ResCode, @Nullable Intent intent) {

        super.onActivityResult(ReqCode, ResCode, intent);

        if(ReqCode ==AC_REQ_CODE){
            if(ResCode==RESULT_OK)
            {
                Place place = Autocomplete.getPlaceFromIntent(intent);
                LocationEdit.setText(place.getName());
                Lat = place.getLatLng().latitude;
                LNG = place.getLatLng().longitude;


            }
            else if(ResCode == AutocompleteActivity.RESULT_ERROR)
            {
                Status status = Autocomplete.getStatusFromIntent(intent);
                Toast.makeText(AddRest.this,status.getStatusMessage(), Toast.LENGTH_SHORT).show();

            }
        }
    }

    public  void openPlacesAuto(View view)
    {
        Places.initialize(getApplicationContext(),"AIzaSyCs5DasLHtR3QZvOuZO2JHMEfj-6R5RWpY");
        PlacesClient placesClient = Places.createClient(this);

        Intent intent = new Autocomplete.IntentBuilder(
                AutocompleteActivityMode.OVERLAY,
                Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)).
                setCountries(Arrays.asList("AU")).
                build(this);
        startActivityForResult(intent, AC_REQ_CODE);

    }

    public void  getCurrLoc(View view)
    {
        FusedLocationProviderClient providerClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AddRest.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOC_PERM_REQ_CODE);
            return;
        }

        providerClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
              Location location = task.getResult();
              if (location !=null)
              {
                  try{
                      Geocoder geocoder = new Geocoder(AddRest.this, Locale.getDefault());

                      List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),
                              location.getLongitude(),1);

                      Lat = addresses.get(0).getLatitude();
                      LNG = addresses.get(0).getLongitude();

                      LocationEdit.setText(addresses.get(0).getAddressLine(0));


                  }

                   catch (IOException e) {
                      Toast.makeText(AddRest.this, e.getMessage(),Toast.LENGTH_SHORT).show();
                  }
              }

            }
        });
    }
    public void Show_Location (View view)
    {
        String Name = NameEdit.getText().toString();
        String Location = LocationEdit.getText().toString();

        if (Name.equals("") || Location.equals(""))
            Toast.makeText(AddRest.this, "Please enter the Name and its Location", Toast.LENGTH_SHORT);
        else {
            Intent intent = new Intent(AddRest.this, MapsActivity.class);

            intent.putExtra(util.Key_Rest_Name, Name);
            intent.putExtra(util.Key_Rest_LAT, Lat);
            intent.putExtra(util.Key_Rest_LNG, LNG);
            startActivity(intent);
        }
    }

    public void savedRest(View view)
    {
        String Name = NameEdit.getText().toString();
        String Location = LocationEdit.getText().toString();

        if (Name.equals("") || Location.equals("")){
            Toast.makeText(AddRest.this,"Please enter name and location", Toast.LENGTH_SHORT).show();
        }
        else {
            DatabaceHelper databaceHelper = new DatabaceHelper(this);

            Rest rest = new Rest(Name,Lat,LNG);

            long Result = databaceHelper.Insert_Restarant(rest);

            if (Result >0)
            {
                Toast.makeText(AddRest.this, "Restaurant Saved", Toast.LENGTH_SHORT).show();
                finish();

            }
            else {
                Toast.makeText(AddRest.this,"Error",Toast.LENGTH_SHORT).show();
            }
        }

    }
}
