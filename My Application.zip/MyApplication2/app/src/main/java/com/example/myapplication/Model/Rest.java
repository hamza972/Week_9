package com.example.myapplication.Model;

public class Rest {
    private  int ID;
    private String Name;
    private  double Lat,LNG;

    public Rest(int ID, String name, double lat, double LNG) {
        this.ID = ID;
        Name = name;
        Lat = lat;
        this.LNG = LNG;
    }

    public Rest(String name, double lat, double LNG) {
        Name = name;
        Lat = lat;
        this.LNG = LNG;
    }

    public String getName() {
        return Name;
    }

    public double getLat() {
        return Lat;
    }

    public double getLNG() {
        return LNG;
    }
}
