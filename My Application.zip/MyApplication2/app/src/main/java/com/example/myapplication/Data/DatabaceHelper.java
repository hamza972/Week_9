package com.example.myapplication.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.Model.Rest;
import com.example.myapplication.Util.util;

import java.util.ArrayList;
import java.util.List;

public class DatabaceHelper extends SQLiteOpenHelper {
    public DatabaceHelper(@Nullable Context context) {
        super(context, util.DATABASE_NAME,  null, util.DATABASE_VERSION);

    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String Create_Res_Table = "Create Table " + util.TABLE_NAME + "(" +
                util.Res_ID + "INTEGER PRIMARY KEY AUTOINCREMENT," +
                util.Res_Name + "TEXT," +
                util.Res_LAT + "REAL," +
                util.Res_LNG + "REAL)";

        db.execSQL(Create_Res_Table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        String Drop_Table = "DROP TABLE IF EXISTS " + util.DATABASE_NAME;

        db.execSQL(Drop_Table);
        this.onCreate(db);

    }
    public long Insert_Restarant (Rest rest)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(util.Res_Name, rest.getName());
        values.put(util.Res_LAT, rest.getLat());
        values.put(util.Res_LNG, rest.getLNG());

        long NewRowID = database.insert(util.TABLE_NAME,null, values);
        database.close();

        return  NewRowID;

    }

    public  List<Rest> getRest()
    {
        SQLiteDatabase database = getReadableDatabase();
        List<Rest> rests = new ArrayList<>();

        String Query = "SELECT * FROM " + util.TABLE_NAME;
        Cursor cursor = database.rawQuery(Query,null);

        if (cursor.moveToFirst())
        {
            while (!cursor.moveToFirst())
            {
                while ( (!cursor.isAfterLast()))
                {
                    int ID = cursor.getInt(cursor.getColumnIndex(util.Res_ID));
                    String Name = cursor.getString(cursor.getColumnIndex(util.Res_Name));
                    double Lat = cursor.getDouble(cursor.getColumnIndex(util.Res_LAT));
                    double LNG = cursor.getDouble(cursor.getColumnIndex(util.Res_LNG));

                    rests.add(new Rest(ID,Name,Lat,LNG));

                    cursor.moveToNext();
                }
            }

        }
        database.close();;
        cursor.close();;
        return rests;

    }
}
